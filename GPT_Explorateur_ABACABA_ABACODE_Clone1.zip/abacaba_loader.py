
import json
import os

class AbacabaConfigLoader:
    def __init__(self, config_path):
        self.config_path = config_path
        self.config = None

    def load(self):
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Configuration file not found: {self.config_path}")
        with open(self.config_path, "r", encoding="utf-8") as f:
            self.config = json.load(f)
        print(f"[✔] Configuration loaded successfully from: {self.config_path}")
        return self.config

    def list_active_features(self):
        if not self.config:
            raise RuntimeError("Configuration not loaded. Call load() first.")
        features = self.config.get("features", {})
        return list(features.keys())

    def get_feature_details(self, feature_name):
        if not self.config:
            raise RuntimeError("Configuration not loaded. Call load() first.")
        return self.config.get("features", {}).get(feature_name, "Feature not found.")

# Exemple d'utilisation
if __name__ == "__main__":
    loader = AbacabaConfigLoader("consolidated_abacaba_final_v3.json")
    config = loader.load()
    print("🔧 Modules actifs :", loader.list_active_features())
    print("📋 Détail d'un module (ex: fibonacci_weighting) :", loader.get_feature_details("fibonacci_weighting"))
