
import pandas as pd
import numpy as np
from collections import Counter

def charger_donnees(path):
    """Charge les données du fichier CSV nettoyé."""
    df = pd.read_csv(path, parse_dates=['date_de_tirage'], dayfirst=True)
    return df

def analyser_frequences(df):
    """Analyse la fréquence des boules principales et étoiles."""
    boules = pd.concat([df[f"boule_{i}"] for i in range(1, 6)])
    etoiles = pd.concat([df["etoile_1"], df["etoile_2"]])

    freq_boules = boules.value_counts().sort_index()
    freq_etoiles = etoiles.value_counts().sort_index()

    return freq_boules, freq_etoiles

def generer_combinaison_probable(freq_boules, freq_etoiles):
    """Génère une combinaison probable basée sur les fréquences les plus élevées."""
    top_boules = freq_boules.sort_values(ascending=False).head(5).index.tolist()
    top_etoiles = freq_etoiles.sort_values(ascending=False).head(2).index.tolist()
    return sorted(top_boules), sorted(top_etoiles)

def executer_analyse_prediction(path_csv):
    df = charger_donnees(path_csv)
    freq_boules, freq_etoiles = analyser_frequences(df)
    combinaison_boules, combinaison_etoiles = generer_combinaison_probable(freq_boules, freq_etoiles)

    return {
        "top_boules_probables": combinaison_boules,
        "top_etoiles_probables": combinaison_etoiles,
        "frequences_boules": freq_boules.to_dict(),
        "frequences_etoiles": freq_etoiles.to_dict()
    }
