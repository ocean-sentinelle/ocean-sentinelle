from analyse_prediction_euromillions import executer_analyse_prediction
from abacaba_loader import AbacabaConfigLoader
import json

# === Paramètres par défaut ===
CSV_TIRAGES_PATH = "Les cinquante derniers tirages Euro Millions.csv"
CONFIG_PATH = "Configuration_Préconfigurée_Pour_Prévisions_EuroMillions_Explorateur_ABACABA.json"

# === Lancement de l'analyse de prédiction ===
def main():
    print("\n=== Lancement de GPT Explorateur ABACABA ABACODE ===")

    print("\n[1] Chargement de la configuration...")
    loader = AbacabaConfigLoader(CONFIG_PATH)
    config = loader.load()
    print("Modules actifs :", loader.list_active_features())

    print("\n[2] Analyse prédictive en cours...")
    resultats = executer_analyse_prediction(CSV_TIRAGES_PATH)

    print("\n=== Résultats de la prédiction : ===")
    print("Top 5 boules probables :", resultats['top_boules_probables'])
    print("Top 2 étoiles probables :", resultats['top_etoiles_probables'])

    # Sauvegarde dans un fichier résultat (optionnel)
    with open("resultats_prediction.json", "w") as f:
        json.dump(resultats, f, indent=4)
    print("\n✅ Résultats enregistrés dans resultats_prediction.json")

if __name__ == "__main__":
    main()